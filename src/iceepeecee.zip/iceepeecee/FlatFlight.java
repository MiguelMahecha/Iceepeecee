package iceepeecee;

public class FlatFlight extends Flight{
    public FlatFlight(String color, int[] from, int[] to) {
        super(color, from, to);
    }
}
